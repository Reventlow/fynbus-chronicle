/* global React */
const { useState, useEffect, useRef } = React;

/* ============================================================
   Icons — minimal stroke set, all 16px, currentColor
   ============================================================ */
const ICONS = {
  dashboard: "M3 13h7V3H3v10zm0 8h7v-6H3v6zm11 0h7v-10h-7v10zm0-18v6h7V3h-7z",
  book:     "M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5a2.5 2.5 0 0 0 0 5H20v-3M4 4.5V21",
  task:     "M9 11l3 3L22 4M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11",
  cal:      "M3 8h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zM8 2v4M16 2v4",
  docs:     "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM14 2v6h6",
  plus:     "M12 5v14M5 12h14",
  search:   "M21 21l-4.35-4.35M11 19a8 8 0 1 1 0-16 8 8 0 0 1 0 16z",
  sun:      "M12 3v2m0 14v2M5.6 5.6l1.4 1.4m10 10l1.4 1.4M3 12h2m14 0h2M5.6 18.4l1.4-1.4m10-10l1.4-1.4M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z",
  moon:     "M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z",
  bell:     "M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0",
  caret:    "M6 9l6 6 6-6",
  more:     "M5 12h.01M12 12h.01M19 12h.01",
  edit:     "M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z",
  download: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3",
  drag:     "M9 5h.01M9 12h.01M9 19h.01M15 5h.01M15 12h.01M15 19h.01",
  check:    "M5 12l5 5L20 7",
  x:        "M18 6L6 18M6 6l12 12",
  arrowUp:  "M12 19V5M5 12l7-7 7 7",
  arrowDn:  "M12 5v14M19 12l-7 7-7-7",
  sparkle:  "M12 3l1.6 4.4L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.6L12 3z",
  alert:    "M12 9v4M12 17h.01M10.3 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z",
  shield:   "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z",
  clock:    "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 6v6l4 2",
  user:     "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z",
  filter:   "M22 3H2l8 9.46V19l4 2v-8.54L22 3z",
  arc:      "M3 12a9 9 0 0 1 9-9M21 12a9 9 0 0 1-9 9",
};

const Icon = ({ name, size = 16, stroke = 1.7, style }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
       stroke="currentColor" strokeWidth={stroke}
       strokeLinecap="round" strokeLinejoin="round" style={style}>
    <path d={ICONS[name]} />
  </svg>
);

/* ============================================================ */
const Pill = ({ tone = "neutral", children, dot = false }) => {
  const palette = {
    neutral:  { bg: "color-mix(in oklch, var(--ink-4) 12%, transparent)", fg: "var(--ink-2)", dot: "var(--ink-4)" },
    accent:   { bg: "var(--accent-soft)",  fg: "var(--accent-ink)", dot: "var(--accent)" },
    good:     { bg: "var(--good-soft)",    fg: "var(--good-ink)",   dot: "var(--good)" },
    warn:     { bg: "var(--warn-soft)",    fg: "var(--warn-ink)",   dot: "var(--warn)" },
    bad:      { bg: "var(--bad-soft)",     fg: "var(--bad-ink)",    dot: "var(--bad)" },
    info:     { bg: "var(--info-soft)",    fg: "var(--info)",       dot: "var(--info)" },
  }[tone] || {};
  return (
    <span className="pill" style={{ background: palette.bg, color: palette.fg }}>
      {dot && <span className="pill-dot" style={{ background: palette.dot }} />}
      {children}
    </span>
  );
};

/* ============================================================
   Top nav + side shell
   ============================================================ */
const Nav = ({ current, onNav, dark, onToggleDark, onToggleTweaks }) => {
  const items = [
    { id: "dashboard",  label: "Kontrolpanel",   icon: "dashboard" },
    { id: "weeklog",    label: "Ugelog",         icon: "book" },
    { id: "tasks",      label: "Opgaver",        icon: "task", disabled: true },
    { id: "oncall",     label: "Rådighedsvagt",  icon: "cal", disabled: true },
    { id: "docs",       label: "Dokumentation",  icon: "docs", disabled: true },
  ];

  return (
    <header style={{
      position: "sticky", top: 0, zIndex: 40,
      background: "color-mix(in oklch, var(--paper) 86%, transparent)",
      backdropFilter: "saturate(140%) blur(14px)",
      WebkitBackdropFilter: "saturate(140%) blur(14px)",
      borderBottom: "1px solid var(--hairline)",
    }}>
      <div style={{
        maxWidth: 1280, margin: "0 auto",
        padding: "12px 28px",
        display: "flex", alignItems: "center", gap: 28,
      }}>
        {/* Brand */}
        <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
          <div style={{
            width: 28, height: 28, borderRadius: 8,
            background: "var(--ink-1)",
            color: "var(--paper)",
            display: "grid", placeItems: "center",
            fontFamily: "var(--font-display)", fontSize: 17, fontStyle: "italic",
            letterSpacing: "-0.04em",
            boxShadow: "0 1px 0 oklch(1 0 0 / 0.15) inset",
          }}>C</div>
          <div style={{ lineHeight: 1.05 }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: "var(--ink-1)", letterSpacing: "-0.02em" }}>Chronicle</div>
            <div style={{ fontSize: 10.5, fontFamily: "var(--font-mono)", color: "var(--ink-4)", textTransform: "uppercase", letterSpacing: "0.08em" }}>FynBus IT</div>
          </div>
        </div>

        {/* Nav links */}
        <nav style={{ display: "flex", gap: 2, marginLeft: 14 }}>
          {items.map(item => {
            const active = current === item.id;
            return (
              <button key={item.id}
                onClick={() => !item.disabled && onNav(item.id)}
                disabled={item.disabled}
                style={{
                  appearance: "none", border: 0,
                  background: active ? "var(--surface-2)" : "transparent",
                  color: active ? "var(--ink-1)" : item.disabled ? "var(--ink-5)" : "var(--ink-3)",
                  padding: "7px 11px", borderRadius: 8,
                  fontSize: 13.5, fontWeight: 500, letterSpacing: "-0.01em",
                  cursor: item.disabled ? "not-allowed" : "pointer",
                  display: "inline-flex", alignItems: "center", gap: 7,
                  transition: "all 0.15s ease",
                }}
                onMouseEnter={e => !item.disabled && !active && (e.currentTarget.style.color = "var(--ink-1)")}
                onMouseLeave={e => !item.disabled && !active && (e.currentTarget.style.color = "var(--ink-3)")}
              >
                <Icon name={item.icon} size={15} />
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Right */}
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6 }}>
          <div style={{
            display: "flex", alignItems: "center", gap: 8,
            padding: "5px 10px 5px 9px",
            background: "var(--surface-2)",
            border: "1px solid var(--hairline)",
            borderRadius: 8,
            fontSize: 12.5, color: "var(--ink-4)",
          }}>
            <Icon name="search" size={13} />
            <span>Søg</span>
            <span style={{
              fontFamily: "var(--font-mono)", fontSize: 10.5,
              background: "var(--surface-1)", padding: "1px 5px", borderRadius: 4,
              border: "1px solid var(--hairline)",
            }}>⌘K</span>
          </div>
          <button className="icon-btn" onClick={onToggleDark} aria-label="Skift tema">
            <Icon name={dark ? "sun" : "moon"} size={15} />
          </button>
          <button className="icon-btn" aria-label="Notifikationer" style={{ position: "relative" }}>
            <Icon name="bell" size={15} />
            <span style={{
              position: "absolute", top: 5, right: 5,
              width: 6, height: 6, borderRadius: 999,
              background: "var(--bad)",
              border: "1.5px solid var(--paper)",
            }} />
          </button>
          <div style={{ width: 1, height: 18, background: "var(--hairline)", margin: "0 4px" }} />
          <button style={{
            display: "inline-flex", alignItems: "center", gap: 8,
            padding: "4px 8px 4px 4px", borderRadius: 8,
            background: "transparent", border: 0, cursor: "pointer", color: "var(--ink-2)",
          }}>
            <div style={{
              width: 24, height: 24, borderRadius: 999,
              background: "linear-gradient(135deg, var(--accent), var(--accent-ink))",
              color: "var(--paper)",
              display: "grid", placeItems: "center",
              fontSize: 11, fontWeight: 600,
            }}>MJ</div>
            <span style={{ fontSize: 13, fontWeight: 500 }}>Mads J.</span>
            <Icon name="caret" size={13} />
          </button>
        </div>
      </div>
    </header>
  );
};

/* ============================================================
   Sparkbars — used in stat cards and chart strip
   ============================================================ */
const Sparkbars = ({ data, height = 36, accent = "var(--accent)" }) => {
  const max = Math.max(...data);
  return (
    <div style={{
      display: "flex", alignItems: "flex-end", gap: 3, height,
    }}>
      {data.map((v, i) => (
        <div key={i} style={{
          flex: 1,
          height: `${Math.max(8, (v / max) * 100)}%`,
          background: i === data.length - 1 ? accent : `color-mix(in oklch, ${accent} 30%, transparent)`,
          borderRadius: "3px 3px 0 0",
          transition: "background 0.2s ease, height 0.4s cubic-bezier(.2,.8,.2,1)",
        }} />
      ))}
    </div>
  );
};

/* ============================================================
   Sparkline (path) — for KPI cards
   ============================================================ */
const Sparkline = ({ data, width = 140, height = 36, accent = "var(--accent)", fill = true }) => {
  if (!data?.length) return null;
  const min = Math.min(...data), max = Math.max(...data);
  const range = max - min || 1;
  const step = width / (data.length - 1);
  const pts = data.map((v, i) => [i * step, height - 4 - ((v - min) / range) * (height - 8)]);
  const path = pts.map((p, i) => `${i ? "L" : "M"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
  const area = `${path} L${width},${height} L0,${height} Z`;
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} style={{ overflow: "visible" }}>
      {fill && (
        <path d={area} fill={accent} opacity="0.10" />
      )}
      <path d={path} fill="none" stroke={accent} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r="3" fill={accent} />
      <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r="6" fill={accent} opacity="0.15" />
    </svg>
  );
};

Object.assign(window, { Icon, Pill, Nav, Sparkbars, Sparkline });
