/* global React, ReactDOM, Nav, Dashboard, WeekLog, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakToggle, TweakSelect */
const { useState, useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "density": "comfy",
  "accent": "gold",
  "serif_h1": true,
  "dark": false
}/*EDITMODE-END*/;

const App = () => {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [page, setPage] = useState("dashboard");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", !!tweaks.dark);
    document.documentElement.dataset.density = tweaks.density;
    document.documentElement.dataset.accent = tweaks.accent;
  }, [tweaks]);

  // serif H1 toggle
  useEffect(() => {
    let style = document.getElementById("serif-toggle");
    if (!style) {
      style = document.createElement("style");
      style.id = "serif-toggle";
      document.head.appendChild(style);
    }
    style.textContent = tweaks.serif_h1
      ? ""
      : `.display { font-family: var(--font-ui) !important; font-style: normal !important; font-weight: 600 !important; letter-spacing: -0.035em !important; }
         .display.italic { font-style: italic !important; color: var(--ink-3) !important; }`;
  }, [tweaks.serif_h1]);

  return (
    <>
      <Nav current={page} onNav={setPage}
           dark={tweaks.dark}
           onToggleDark={() => setTweak("dark", !tweaks.dark)} />

      {page === "dashboard" && <Dashboard />}
      {page === "weeklog"   && <WeekLog />}

      <TweaksPanel title="Tweaks">
        <TweakSection title="Tæthed">
          <TweakRadio
            value={tweaks.density}
            onChange={v => setTweak("density", v)}
            options={[{ value: "comfy", label: "Behagelig" }, { value: "compact", label: "Kompakt" }]} />
        </TweakSection>
        <TweakSection title="Accent">
          <TweakRadio
            value={tweaks.accent}
            onChange={v => setTweak("accent", v)}
            options={[
              { value: "gold", label: "Guld" },
              { value: "sage", label: "Salvie" },
              { value: "terracotta", label: "Terra" },
              { value: "ink", label: "Blæk" },
            ]} />
        </TweakSection>
        <TweakSection title="Typografi">
          <TweakToggle
            label="Editorial serif headlines"
            value={tweaks.serif_h1}
            onChange={v => setTweak("serif_h1", v)} />
        </TweakSection>
        <TweakSection title="Tema">
          <TweakToggle
            label="Mørk tilstand"
            value={tweaks.dark}
            onChange={v => setTweak("dark", v)} />
        </TweakSection>
      </TweaksPanel>
    </>
  );
};

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
