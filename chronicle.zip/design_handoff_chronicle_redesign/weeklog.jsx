/* global React, Icon, Pill */
const { useState, useRef, useEffect } = React;

const initialPriorities = [
  { id: 1, done: true,  text: "Færdiggør M365 license rebalancing-rapport",            tag: "M365",     owner: "AS" },
  { id: 2, done: false, text: "Aftal RFP-møde med leverandør om netværksopgradering",   tag: "Netværk",  owner: "MJ" },
  { id: 3, done: false, text: "Review af ZTNA pilot — feedback fra depot Svendborg",    tag: "Sikkerhed",owner: "LK" },
  { id: 4, done: false, text: "Opdater incident runbook for Veeam backup",              tag: "Drift",    owner: "PK" },
  { id: 5, done: false, text: "Kvartalsrapport — KPI'er til ledelsen",                  tag: "Rapport",  owner: "MJ" },
];

const absences = [
  { who: "Anders Steen", role: "Helpdesk lead", from: "Tor 23. apr", to: "Fre 24. apr", kind: "Ferie",      tone: "info" },
  { who: "Pernille K.",  role: "Sikkerhed",     from: "Hele uge 17", to: "",            kind: "Konference", tone: "accent" },
  { who: "Lasse K.",     role: "Drift",         from: "Man 21. apr", to: "Man 21. apr", kind: "Sygdom",     tone: "warn" },
];

const incidents = [
  { sev:"P1", title:"ServiceDesk Plus utilgængelig", system:"ManageEngine", started:"22. apr 14:32", duration:"47 min", owner:"AS",
    summary:"Database-replikering fejlede efter planlagt opdatering. Failover til standby-instans tog længere tid end forventet pga. cache-warmup. Tickets udestående: 12 (alle håndteret retroaktivt)." },
  { sev:"P2", title:"Phishing-kampagne mod administration", system:"M365 Defender", started:"22. apr 09:11", duration:"2 t 14 min", owner:"PK",
    summary:"47 medarbejdere modtog SMS-phishing imiterende HR. 3 klikkede, 0 indtastede credentials. Awareness-besked udsendt 10:30." },
  { sev:"P3", title:"Wi-Fi udfald, depot Svendborg", system:"Cisco Meraki", started:"21. apr 16:04", duration:"38 min", owner:"MJ",
    summary:"AP-controller i Svendborg mistede uplink. Failover til 4G backup virkede. Skift til ny SD-WAN-rute planlagt." },
];

const meetingMinutes = [
  { time:"man 09:00", title:"Mandag stand-up", attendees:["MJ","AS","LK","PK"], minutes:"Gennemgang af ServiceDesk-incidenten. Beslutning: kør postmortem fredag." },
  { time:"ons 13:30", title:"Sikkerhedsforum",  attendees:["PK","LK"],          minutes:"ZTNA pilot status grøn. Roll-out til administration uge 19." },
];

const WeekLog = () => {
  const [tab, setTab] = useState("overview");
  const [items, setItems] = useState(initialPriorities);
  const [adding, setAdding] = useState(false);
  const [draft, setDraft] = useState("");
  const inputRef = useRef(null);

  useEffect(() => { if (adding) inputRef.current?.focus(); }, [adding]);

  const toggle = (id) => setItems(items.map(it => it.id === id ? { ...it, done: !it.done } : it));
  const remove = (id) => setItems(items.filter(it => it.id !== id));
  const submit = () => {
    if (draft.trim()) {
      setItems([...items, { id: Date.now(), done: false, text: draft, tag: "Nyt", owner: "MJ" }]);
      setDraft("");
    }
    setAdding(false);
  };

  const tabs = [
    { id: "overview",  label: "Overblik" },
    { id: "tasks",     label: "Prioriteter", count: items.filter(i => !i.done).length },
    { id: "absences",  label: "Bemanding",   count: absences.length },
    { id: "incidents", label: "Hændelser",   count: incidents.length },
    { id: "minutes",   label: "Mødereferater" },
  ];

  return (
    <div style={{ padding: "32px 28px 80px", maxWidth: 1180, margin: "0 auto" }}>

      {/* Breadcrumb */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12.5, color: "var(--ink-4)", marginBottom: 18 }}>
        <a style={{ color: "inherit", textDecoration: "none", cursor: "pointer" }}>Ugelogs</a>
        <span style={{ color: "var(--ink-5)" }}>/</span>
        <a style={{ color: "inherit", textDecoration: "none", cursor: "pointer" }}>2026</a>
        <span style={{ color: "var(--ink-5)" }}>/</span>
        <span style={{ color: "var(--ink-2)" }}>Uge 17</span>
      </div>

      {/* === Editorial header ========================================== */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "1fr auto",
        gap: 28, alignItems: "flex-end",
        marginBottom: 32, paddingBottom: 28,
        borderBottom: "1px solid var(--hairline)",
      }}>
        <div>
          <div className="label-eyebrow" style={{ marginBottom: 14 }}>
            Ugentlig rapport · IT-afdelingen
          </div>
          <h1 className="display" style={{ margin: 0, fontSize: 64, lineHeight: 1, letterSpacing: "-0.02em" }}>
            Uge 17, <span className="display italic" style={{ color: "var(--ink-3)" }}>2026</span>
          </h1>
          <div style={{ display: "flex", alignItems: "center", gap: 16, marginTop: 16, flexWrap: "wrap" }}>
            <div style={{ fontSize: 14, color: "var(--ink-3)" }}>
              <span style={{ fontFamily: "var(--font-mono)", color: "var(--ink-2)" }}>21 apr — 27 apr</span>
              <span style={{ color: "var(--ink-5)", margin: "0 10px" }}>·</span>
              <span>Skrevet af <strong style={{ color: "var(--ink-1)", fontWeight: 600 }}>Mads Jensen</strong></span>
              <span style={{ color: "var(--ink-5)", margin: "0 10px" }}>·</span>
              <span>Sidst opdateret <span style={{ fontFamily: "var(--font-mono)" }}>i går 16:42</span></span>
            </div>
            <Pill tone="accent" dot>Kladde</Pill>
          </div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn btn-sm"><Icon name="edit" size={13} />Rediger</button>
          <button className="btn btn-sm"><Icon name="download" size={13} />Eksportér<Icon name="caret" size={12}/></button>
          <button className="btn btn-primary btn-sm"><Icon name="check" size={13} />Publicér</button>
        </div>
      </div>

      {/* === Tabs ====================================================== */}
      <div style={{
        display: "flex", gap: 2,
        borderBottom: "1px solid var(--hairline)",
        marginBottom: 24,
        overflowX: "auto",
      }}>
        {tabs.map(t => {
          const active = tab === t.id;
          return (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              appearance: "none", border: 0, background: "transparent",
              padding: "10px 14px",
              borderBottom: `2px solid ${active ? "var(--ink-1)" : "transparent"}`,
              marginBottom: -1,
              color: active ? "var(--ink-1)" : "var(--ink-3)",
              fontSize: 13.5, fontWeight: 500, letterSpacing: "-0.01em",
              cursor: "pointer",
              display: "inline-flex", alignItems: "center", gap: 7,
            }}>
              {t.label}
              {t.count != null && (
                <span style={{
                  fontSize: 11, fontFamily: "var(--font-mono)",
                  background: active ? "var(--surface-2)" : "transparent",
                  color: "var(--ink-4)",
                  padding: "1px 6px", borderRadius: 999,
                  border: "1px solid var(--hairline)",
                }}>{t.count}</span>
              )}
            </button>
          );
        })}
      </div>

      {tab === "overview" && (
        <Overview items={items} />
      )}

      {tab === "tasks" && (
        <div className="card" style={{ padding: 0 }}>
          <SectionHead title="Prioriterede opgaver" sub="Træk for at omarrangere · klik for at krydse af">
            <button className="btn btn-sm" onClick={() => setAdding(true)}><Icon name="plus" size={13} />Tilføj</button>
          </SectionHead>

          <div>
            {items.map((it, i) => (
              <div key={it.id} className="row-hoverable" style={{
                display: "grid",
                gridTemplateColumns: "auto auto 1fr auto auto auto",
                alignItems: "center", gap: 14,
                padding: "var(--row-y) 24px",
                borderTop: "1px solid var(--hairline)",
                opacity: it.done ? 0.55 : 1,
                transition: "opacity 0.2s",
              }}>
                <span className="drag-handle" style={{ width: 14 }}>
                  <Icon name="drag" size={14} />
                </span>
                <span className={`check ${it.done ? "is-checked" : ""}`} onClick={() => toggle(it.id)}>
                  {it.done && <Icon name="check" size={11} stroke={2.5} />}
                </span>
                <div style={{
                  fontSize: 14, color: "var(--ink-1)", fontWeight: 500,
                  textDecoration: it.done ? "line-through" : "none",
                  textDecorationColor: "var(--ink-4)",
                }}>
                  {it.text}
                </div>
                <Pill tone="neutral">{it.tag}</Pill>
                <div style={{
                  width: 24, height: 24, borderRadius: 999,
                  background: "color-mix(in oklch, var(--ink-3) 18%, transparent)",
                  color: "var(--ink-1)",
                  display: "grid", placeItems: "center",
                  fontSize: 10.5, fontWeight: 600,
                }}>{it.owner}</div>
                <button className="icon-btn" onClick={() => remove(it.id)} aria-label="Fjern">
                  <Icon name="x" size={13} />
                </button>
              </div>
            ))}

            {adding && (
              <div className="animate-in" style={{
                display: "grid",
                gridTemplateColumns: "auto auto 1fr auto",
                alignItems: "center", gap: 14,
                padding: "10px 24px",
                borderTop: "1px solid var(--hairline)",
                background: "var(--surface-2)",
              }}>
                <span style={{ width: 14 }} />
                <span className="check" />
                <input ref={inputRef}
                  className="field"
                  placeholder="Beskriv opgave… (Enter for at gemme, Esc for at annullere)"
                  value={draft}
                  onChange={e => setDraft(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === "Enter") submit();
                    if (e.key === "Escape") { setAdding(false); setDraft(""); }
                  }}
                  onBlur={submit}
                  style={{ background: "var(--surface-1)" }}
                />
                <span />
              </div>
            )}
          </div>
        </div>
      )}

      {tab === "absences" && (
        <div className="card" style={{ padding: 0 }}>
          <SectionHead title="Bemanding" sub="Fravær og særlige hændelser denne uge">
            <button className="btn btn-sm"><Icon name="plus" size={13}/>Tilføj</button>
          </SectionHead>
          <div>
            {absences.map((a, i) => (
              <div key={i} style={{
                display: "grid",
                gridTemplateColumns: "auto 1fr auto auto auto",
                alignItems: "center", gap: 14,
                padding: "var(--row-y) 24px",
                borderTop: "1px solid var(--hairline)",
              }}>
                <div style={{
                  width: 32, height: 32, borderRadius: 999,
                  background: "linear-gradient(135deg, var(--accent), var(--accent-ink))",
                  color: "var(--paper)",
                  display: "grid", placeItems: "center",
                  fontSize: 12, fontWeight: 600,
                }}>{a.who.split(" ").map(s=>s[0]).join("").slice(0,2)}</div>
                <div>
                  <div style={{ fontSize: 14, color: "var(--ink-1)", fontWeight: 500 }}>{a.who}</div>
                  <div style={{ fontSize: 12, color: "var(--ink-4)", marginTop: 2 }}>{a.role}</div>
                </div>
                <Pill tone={a.tone}>{a.kind}</Pill>
                <div style={{ fontSize: 12.5, color: "var(--ink-3)", fontFamily: "var(--font-mono)", textAlign: "right", minWidth: 200 }}>
                  {a.from}{a.to && a.to !== a.from && ` → ${a.to}`}
                </div>
                <button className="icon-btn"><Icon name="more" size={14} /></button>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === "incidents" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "var(--gutter)" }}>
          <SummaryRow incidents={incidents} />
          {incidents.map((inc, i) => <IncidentCard key={i} {...inc} />)}
        </div>
      )}

      {tab === "minutes" && (
        <div className="card" style={{ padding: 0 }}>
          <SectionHead title="Mødereferater" sub="Synkroniseret fra Outlook" />
          {meetingMinutes.map((m, i) => (
            <div key={i} style={{
              padding: "16px 24px",
              borderTop: "1px solid var(--hairline)",
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--ink-4)", textTransform: "uppercase", letterSpacing: "0.06em" }}>{m.time}</span>
                <span style={{ color: "var(--ink-5)" }}>·</span>
                <h3 style={{ margin: 0, fontSize: 14.5, color: "var(--ink-1)", fontWeight: 600, letterSpacing: "-0.01em" }}>{m.title}</h3>
                <div style={{ display: "flex", marginLeft: 8 }}>
                  {m.attendees.map((a, j) => (
                    <span key={j} style={{
                      width: 22, height: 22, borderRadius: 999,
                      background: "color-mix(in oklch, var(--ink-3) 18%, transparent)",
                      color: "var(--ink-1)",
                      display: "grid", placeItems: "center",
                      fontSize: 10, fontWeight: 600,
                      marginLeft: j ? -6 : 0,
                      border: "1.5px solid var(--surface-1)",
                    }}>{a}</span>
                  ))}
                </div>
              </div>
              <p style={{ margin: "10px 0 0", fontSize: 13.5, color: "var(--ink-2)", lineHeight: 1.55, maxWidth: 720 }}>
                {m.minutes}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const SectionHead = ({ title, sub, children }) => (
  <div style={{
    display: "flex", alignItems: "center", justifyContent: "space-between",
    padding: "20px 24px 16px",
  }}>
    <div>
      <h2 style={{ margin: 0, fontSize: 16, fontWeight: 600, color: "var(--ink-1)", letterSpacing: "-0.015em" }}>{title}</h2>
      {sub && <div style={{ marginTop: 3, fontSize: 12.5, color: "var(--ink-4)" }}>{sub}</div>}
    </div>
    {children}
  </div>
);

const Overview = ({ items }) => (
  <div style={{
    display: "grid",
    gridTemplateColumns: "minmax(0, 2fr) minmax(0, 1fr)",
    gap: "var(--gutter)",
  }}>
    <div style={{ display: "flex", flexDirection: "column", gap: "var(--gutter)" }}>
      {/* Pull-quote summary */}
      <div className="card" style={{ padding: 32 }}>
        <div className="label-eyebrow">Sammendrag</div>
        <p className="display" style={{
          margin: "12px 0 0", fontSize: 26, lineHeight: 1.3,
          color: "var(--ink-1)", letterSpacing: "-0.01em",
        }}>
          Stille uge på helpdesk-fronten — <span className="display italic" style={{ color: "var(--ink-3)" }}>nettoreduktion på fire sager</span> trods to større hændelser. ZTNA-pilot er igangsat og ServiceDesk-postmortem afsluttes fredag.
        </p>
        <div style={{
          display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 24,
          marginTop: 28, paddingTop: 24, borderTop: "1px solid var(--hairline)",
        }}>
          {[
            { k:"Nye sager",     v:"51", d:"+4" },
            { k:"Lukkede sager", v:"55", d:"+3" },
            { k:"Åbne",          v:"134", d:"−4" },
            { k:"Hændelser",     v:"3",  d:"−2" },
          ].map((s, i) => (
            <div key={i}>
              <div className="label-eyebrow" style={{ fontSize: 10 }}>{s.k}</div>
              <div className="num" style={{ marginTop: 6, fontSize: 28, fontWeight: 500, color: "var(--ink-1)", letterSpacing: "-0.03em" }}>{s.v}</div>
              <div style={{ marginTop: 2, fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--ink-4)" }}>vs. uge 16: {s.d}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Highlights */}
      <div className="card">
        <SectionHead title="Højdepunkter" sub="Hvad fungerede og hvad gjorde ikke" />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, padding: "0 24px 24px" }}>
          <div>
            <div className="label-eyebrow" style={{ color: "var(--good-ink)" }}>+ Plus</div>
            <ul style={{ margin: "8px 0 0", padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 8 }}>
              {["Netto sagsreduktion bedste i Q2", "ZTNA pilot kører grønt på depot Svendborg", "M365 license rebalancing sparer 14k DKK/mdr"].map((x, i) => (
                <li key={i} style={{ display: "flex", gap: 10, fontSize: 13.5, color: "var(--ink-2)", lineHeight: 1.5 }}>
                  <span style={{ color: "var(--good)", marginTop: 6, fontSize: 6 }}>●</span>
                  {x}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <div className="label-eyebrow" style={{ color: "var(--bad-ink)" }}>− Minus</div>
            <ul style={{ margin: "8px 0 0", padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 8 }}>
              {["ServiceDesk-nedetid på 47 min skabte backlog", "Veeam backup degraded — endnu ikke løst", "Phishing-bølge ramte administration"].map((x, i) => (
                <li key={i} style={{ display: "flex", gap: 10, fontSize: 13.5, color: "var(--ink-2)", lineHeight: 1.5 }}>
                  <span style={{ color: "var(--bad)", marginTop: 6, fontSize: 6 }}>●</span>
                  {x}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>

    <div style={{ display: "flex", flexDirection: "column", gap: "var(--gutter)" }}>
      {/* Mini priorities */}
      <div className="card" style={{ padding: 0 }}>
        <SectionHead title="Top prioriteter" />
        <div>
          {items.slice(0, 4).map((it, i) => (
            <div key={it.id} style={{
              display: "flex", alignItems: "center", gap: 12,
              padding: "10px 24px",
              borderTop: "1px solid var(--hairline)",
            }}>
              <span className={`check ${it.done ? "is-checked" : ""}`} style={{ pointerEvents: "none" }}>
                {it.done && <Icon name="check" size={11} stroke={2.5} />}
              </span>
              <div style={{
                flex: 1, fontSize: 13, color: "var(--ink-1)",
                textDecoration: it.done ? "line-through" : "none",
                textDecorationColor: "var(--ink-4)",
                opacity: it.done ? 0.5 : 1,
              }}>{it.text}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Mini incidents */}
      <div className="card" style={{ padding: 0 }}>
        <SectionHead title="Hændelser" />
        <div>
          {incidents.map((inc, i) => (
            <div key={i} style={{
              display: "grid", gridTemplateColumns: "auto 1fr auto",
              alignItems: "center", gap: 12,
              padding: "11px 24px",
              borderTop: "1px solid var(--hairline)",
            }}>
              <Pill tone={inc.sev === "P1" ? "bad" : inc.sev === "P2" ? "warn" : "neutral"}>{inc.sev}</Pill>
              <div style={{ fontSize: 13, color: "var(--ink-1)", fontWeight: 500 }}>{inc.title}</div>
              <span style={{ fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--ink-4)" }}>{inc.duration}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

const SummaryRow = ({ incidents }) => (
  <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "var(--gutter)" }}>
    {[
      { tone:"bad",  count: incidents.filter(i=>i.sev==="P1").length, label: "P1 · kritiske" },
      { tone:"warn", count: incidents.filter(i=>i.sev==="P2").length, label: "P2 · høj" },
      { tone:"neutral", count: incidents.filter(i=>i.sev==="P3").length, label: "P3 · lav" },
    ].map((s, i) => (
      <div key={i} className="card" style={{ display: "flex", alignItems: "center", gap: 16 }}>
        <div style={{
          width: 44, height: 44, borderRadius: 12,
          background: s.tone === "bad" ? "var(--bad-soft)" : s.tone === "warn" ? "var(--warn-soft)" : "var(--surface-2)",
          color: s.tone === "bad" ? "var(--bad-ink)" : s.tone === "warn" ? "var(--warn-ink)" : "var(--ink-3)",
          display: "grid", placeItems: "center",
        }}>
          <Icon name={s.tone === "bad" ? "alert" : s.tone === "warn" ? "shield" : "clock"} size={20} stroke={1.8} />
        </div>
        <div>
          <div className="num" style={{ fontSize: 26, fontWeight: 500, color: "var(--ink-1)", letterSpacing: "-0.03em", lineHeight: 1 }}>{s.count}</div>
          <div style={{ marginTop: 4, fontSize: 12, color: "var(--ink-3)" }}>{s.label}</div>
        </div>
      </div>
    ))}
  </div>
);

const IncidentCard = ({ sev, title, system, started, duration, owner, summary }) => {
  const [open, setOpen] = useState(sev === "P1");
  const tone = sev === "P1" ? "bad" : sev === "P2" ? "warn" : "neutral";
  return (
    <div className="card" style={{ padding: 0, overflow: "hidden" }}>
      <div onClick={() => setOpen(!open)} style={{
        display: "grid",
        gridTemplateColumns: "auto 1fr auto auto",
        alignItems: "center", gap: 16,
        padding: "16px 24px", cursor: "pointer",
      }}>
        <Pill tone={tone}>{sev}</Pill>
        <div>
          <h3 style={{ margin: 0, fontSize: 15, color: "var(--ink-1)", fontWeight: 600, letterSpacing: "-0.01em" }}>{title}</h3>
          <div style={{ marginTop: 4, display: "flex", gap: 12, fontSize: 12, color: "var(--ink-4)" }}>
            <span>{system}</span>
            <span style={{ fontFamily: "var(--font-mono)" }}>{started}</span>
            <span>· varighed <span style={{ fontFamily: "var(--font-mono)", color: "var(--ink-2)" }}>{duration}</span></span>
            <span>· {owner}</span>
          </div>
        </div>
        <div style={{
          width: 24, height: 24, borderRadius: 999,
          background: "color-mix(in oklch, var(--ink-3) 18%, transparent)",
          color: "var(--ink-1)",
          display: "grid", placeItems: "center",
          fontSize: 10.5, fontWeight: 600,
        }}>{owner}</div>
        <span style={{ color: "var(--ink-4)", transform: open ? "rotate(180deg)" : "none", transition: "transform 0.2s" }}>
          <Icon name="caret" size={14} />
        </span>
      </div>
      {open && (
        <div className="animate-in" style={{
          padding: "0 24px 22px",
          borderTop: "1px solid var(--hairline)",
          paddingTop: 18, marginTop: 0,
          background: "var(--surface-2)",
        }}>
          <div className="label-eyebrow" style={{ marginBottom: 8 }}>Sammendrag</div>
          <p style={{ margin: 0, fontSize: 13.5, color: "var(--ink-2)", lineHeight: 1.6, maxWidth: 760 }}>
            {summary}
          </p>
          <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
            <button className="btn btn-sm">Se postmortem</button>
            <button className="btn btn-sm btn-ghost">Tickets · 12</button>
          </div>
        </div>
      )}
    </div>
  );
};

Object.assign(window, { WeekLog });
