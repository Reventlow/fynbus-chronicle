# Handoff: FynBus Chronicle — UI Redesign

## Overview
This bundle contains a redesigned visual language for **FynBus Chronicle**, the Django/HTMX weekly IT logbook. Two screens are mocked at high fidelity: the **Kontrolpanel (Dashboard)** and the **Ugelog detail** view. The redesign keeps the existing Scandinavian sand palette but tightens hierarchy, introduces editorial display type, normalizes color tokens to OKLCH, and adds a denser KPI/chart strip on the dashboard.

## About the Design Files
The HTML/JSX files in this bundle are **design references**, not production code. They are a React-in-the-browser prototype used to demonstrate look-and-feel, type pairings, color tokens, hover/expand states, and layout proportions.

Your task is to **re-implement them in the existing Chronicle codebase** — Django templates + Tailwind CSS + HTMX + Alpine.js — following the patterns already established in `templates/` and `static/src/input.css`. Do **not** ship the React/JSX files. Translate the design tokens into `tailwind.config.js` and the components into Django partials.

## Fidelity
**High-fidelity.** Colors, type sizes, spacing, shadows, hover/expand states, and chart styling are all final. Recreate them precisely.

## Stack alignment
The target codebase is:
- Django 5 templates (server-rendered)
- Tailwind CSS (config in `tailwind.config.js`, source in `static/src/input.css`)
- HTMX for partial swaps & inline editing
- Alpine.js for client state (dropdowns, theme toggle, expand/collapse)
- Chart.js for charts
- SortableJS for drag-reorder
- Inter font (currently) → **switch to Inter Tight + Instrument Serif + JetBrains Mono**

Keep using HTMX for inline add/edit/delete on priority items, absences, incidents. Keep Alpine for the small client interactions. Do not introduce React.

---

## Design Tokens (translate into `tailwind.config.js` and CSS variables)

### Fonts
Replace the current Google Fonts import with:
```html
<link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@300;400;500;600;700&family=Instrument+Serif:ital@0;1&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
```
- **UI / body / headings:** `Inter Tight`
- **Editorial display (page H1 only):** `Instrument Serif`, regular and italic
- **Monospace (timestamps, KPIs, eyebrows, codes):** `JetBrains Mono`

Tailwind:
```js
fontFamily: {
  sans:    ['Inter Tight', 'system-ui', 'sans-serif'],
  display: ['Instrument Serif', 'Georgia', 'serif'],
  mono:    ['JetBrains Mono', 'ui-monospace', 'monospace'],
}
```

### Color tokens (CSS variables, OKLCH)
Define on `:root` and override on `html.dark`. The current Tailwind sand/sage/terracotta/gold palette stays available for legacy bits, but **new components should use these semantic tokens.**

#### Light mode (`:root`)
| Token | Value | Use |
|---|---|---|
| `--paper` | `oklch(0.985 0.004 80)` | page bg |
| `--surface-1` | `oklch(0.998 0.002 80)` | card bg |
| `--surface-2` | `oklch(0.965 0.006 80)` | wells, hover, recessed |
| `--hairline` | `oklch(0.88 0.008 80 / 0.65)` | dividers |
| `--hairline-strong` | `oklch(0.82 0.012 80 / 0.85)` | input borders |
| `--ink-1` | `oklch(0.22 0.012 250)` | headings |
| `--ink-2` | `oklch(0.36 0.010 250)` | body |
| `--ink-3` | `oklch(0.52 0.008 250)` | secondary |
| `--ink-4` | `oklch(0.66 0.006 250)` | labels, eyebrow |
| `--ink-5` | `oklch(0.78 0.005 250)` | placeholder |
| `--accent` (gold) | `oklch(0.62 0.10 75)` | brand accent |
| `--accent-soft` | `oklch(0.96 0.04 80)` | accent backgrounds |
| `--accent-ink` | `oklch(0.42 0.10 75)` | accent text on soft bg |
| `--good` | `oklch(0.55 0.06 145)` | success / sage |
| `--good-soft` | `oklch(0.95 0.025 145)` | |
| `--good-ink` | `oklch(0.38 0.06 145)` | |
| `--warn` | `oklch(0.68 0.12 70)` | warning |
| `--warn-soft` | `oklch(0.96 0.05 75)` | |
| `--warn-ink` | `oklch(0.45 0.10 70)` | |
| `--bad` | `oklch(0.55 0.13 25)` | terracotta / danger |
| `--bad-soft` | `oklch(0.95 0.03 25)` | |
| `--bad-ink` | `oklch(0.40 0.12 25)` | |
| `--info` | `oklch(0.55 0.10 245)` | blue accent for "new tickets" series |
| `--info-soft` | `oklch(0.95 0.025 245)` | |

#### Dark mode (`html.dark`)
| Token | Value |
|---|---|
| `--paper` | `oklch(0.16 0.008 250)` |
| `--surface-1` | `oklch(0.205 0.010 250)` |
| `--surface-2` | `oklch(0.185 0.009 250)` |
| `--hairline` | `oklch(0.40 0.010 250 / 0.45)` |
| `--hairline-strong` | `oklch(0.50 0.012 250 / 0.65)` |
| `--ink-1` | `oklch(0.97 0.005 80)` |
| `--ink-2` | `oklch(0.86 0.006 80)` |
| `--ink-3` | `oklch(0.70 0.008 250)` |
| `--ink-4` | `oklch(0.58 0.010 250)` |
| `--ink-5` | `oklch(0.46 0.010 250)` |
| `--accent` | `oklch(0.78 0.12 80)` |
| `--accent-soft` | `oklch(0.32 0.07 80)` |
| `--accent-ink` | `oklch(0.85 0.10 80)` |
| `--good` | `oklch(0.78 0.08 145)` |
| `--good-soft` | `oklch(0.30 0.05 145)` |
| `--good-ink` | `oklch(0.85 0.07 145)` |
| `--warn` | `oklch(0.82 0.12 75)` |
| `--warn-soft` | `oklch(0.32 0.07 75)` |
| `--warn-ink` | `oklch(0.88 0.10 75)` |
| `--bad` | `oklch(0.72 0.14 25)` |
| `--bad-soft` | `oklch(0.30 0.07 25)` |
| `--bad-ink` | `oklch(0.85 0.10 25)` |
| `--info` | `oklch(0.78 0.10 240)` |
| `--info-soft` | `oklch(0.30 0.06 245)` |

The dark palette is intentionally **slate-cool**, not warm-brown like the current implementation — fixes the muddy feel.

### Shadows (use as `box-shadow`, not Tailwind classes)
- **Card:**
  ```
  0 0 0 0.5px oklch(0.78 0.01 250 / 0.18),
  0 1px 1px oklch(0.5 0 0 / 0.03),
  0 4px 12px oklch(0.5 0 0 / 0.04)
  ```
- **Card (dark):**
  ```
  0 0 0 0.5px oklch(1 0 0 / 0.06),
  0 1px 1px oklch(0 0 0 / 0.4),
  0 4px 12px oklch(0 0 0 / 0.35)
  ```
- **Pop / dropdown:** Same idea, larger spread (see `Chronicle Redesign.html` `--shadow-pop`).

### Spacing & radius
- Card padding: `24px` comfy / `18px` compact
- Card radius: `14px` (down from current 16px)
- Pill radius: `999px`, padding `3px 9px`, font-size `11.5px`
- Button radius: `9px` (sm: `7px`)
- Grid gutter: `20px` comfy / `14px` compact

### Density modifier
Add `data-density="compact"` on `<html>` to scale down. Drive via Alpine + localStorage (same pattern as current dark mode toggle).

---

## Screens

### 1. Application shell (`templates/base.html` + `templates/components/nav.html`)

**Top nav** (replaces current nav):
- Sticky at top, `backdrop-filter: blur(14px)` over `--paper` at 86% opacity, 1px `--hairline` bottom border.
- Max-width 1280px, padding `12px 28px`.
- Brand mark: 28×28 black-ink rounded square (8px radius) with serif italic "C" in `--paper`. Right of it, 2-line lockup: "Chronicle" (14px, weight 600, ink-1) above a mono eyebrow "FYNBUS IT" (10.5px, ink-4, uppercase, letter-spacing 0.08em).
- Nav links: 13.5px, weight 500, ink-3 default, ink-1 hover, `--surface-2` background + ink-1 when active. Each link has a 15px stroked icon to the left.
- Right cluster: search affordance (well-styled `<div>` showing "Søg ⌘K"), theme toggle icon button, bell with red dot, vertical hairline divider, user button (24px gradient avatar from `--accent` → `--accent-ink`, name, caret).

**Page wrapper**: max-width 1280px, padding `32px 28px 80px`, no card wrapping the whole page (the current `<main>` styling is too constrained).

### 2. Kontrolpanel / Dashboard (`templates/dashboard/index.html`)

#### Header band
- Eyebrow: mono "Uge 17 · 21–27 apr 2026", color ink-4
- H1: **Instrument Serif 48px, line-height 1.05**: "Godmorgen, {{ user.first_name }}." then in italic ink-3: "her er ugen."
- Sub-line (ink-3, 14.5px): live dot (pulsing `--good` with `pulseGlow` keyframe) + "Live · synkroniseret kl HH:MM", separators "·", "N hændelser denne uge", "Rådighedsvagt: {{ oncall.name }}".
- Right side: "Eksportér" (secondary) + "Ny ugelog" (primary, dark ink-1 button).

#### KPI strip — 4 cards, equal columns
Each card:
- Card shadow + 14px radius, padding 24px, flex column gap 12px.
- Top row: mono eyebrow label (left) + tiny delta pill (right), pill is `--good-soft`/`--warn-soft`/`--bad-soft` depending on direction, mono font, "▲4" / "▼7" format.
- Big number: `Inter Tight` 38px weight 500, letter-spacing -0.04em, tabular-nums, ink-1.
- Mini chart: `Sparkline` (path + fill 10%, last point a dot with halo) for tickets-style series, or `Sparkbars` (right-aligned vertical bars, last bar full-accent, others 30% accent) for net deltas.
- Cards: Åbne sager (gold sparkline), Nye sager (info/blue sparkline), Lukkede sager (good/sage sparkline), Netto (bars, ink accent, optional sublabel "bedste uge i kvartalet").

#### Main grid — chart (1.7fr) + side rail (1fr)

**Chart card** (replaces current Chart.js block):
- Header: eyebrow "Helpdesk · 12 uger" + H2 "Ny vs. lukket — flow over tid" (17px, weight 600, letter-spacing -0.02em). Right: pill segmented control "12U / 26U / 12M" (active = surface-1 with subtle shadow).
- Chart body: 720×220 viewBox SVG (re-implement with Chart.js if preferred). Two area+line series: `--info` (new) and `--good` (closed), both at 10%/8% area opacity. Dashed gridlines. Mono axis labels in ink-4. Hover: vertical dashed crosshair, dots on both lines, floating tooltip card with mono week label and colored "● Nye N" / "● Lukket N" lines.
- Footer: 12px legend rows + right-aligned mono caption "Kilde: ManageEngine · synk hver 30. min". Top hairline border.

**Side rail (column, gap = `--gutter`)**:

*On-call card* — gradient from `--surface-1` to `accent-soft`-tinted, 44px circular gradient avatar, name (16px weight 600 ink-1), "Til mandag 08:00 · uge 17" sub. Two equal buttons: "Se kalender" / "Skift".

*Systemstatus card* — header row: eyebrow + "Alt i drift på nær én" + good pill "3/4 OK". Then 4 status rows separated by hairlines, each: dot (good/warn/bad, pulsing if not good) + system name + right-aligned mono uptime/state.

#### Tasks + Incidents row — 2 equal cards

**Prioriterede opgaver**: header row inside card with eyebrow + H2 "I gang denne uge" + ghost "Tilføj" button. Rows are `display: grid` with columns `auto 1fr auto auto`: 24px circular owner badge, title + 90px progress bar (4px height, accent fill, bad-fill if blocked) + "%", state pill, 36px right-aligned mono due-day.

**Hændelser**: 6px-wide colored severity rail on left (bad/warn/ink-4), title + meta row of mono timestamp / system / owner code, P1/P2/P3 pill on right.

### 3. Ugelog detail (`templates/logbook/weeklog_detail.html`)

#### Breadcrumb
12.5px ink-4 row: "Ugelogs / 2026 / Uge 17", trailing crumb in ink-2.

#### Editorial header — bottom-bordered band
- Eyebrow (mono, ink-4): "Ugentlig rapport · IT-afdelingen"
- H1: **Instrument Serif 64px, line-height 1, letter-spacing -0.02em**: "Uge 17, " + italic ink-3 "{{ year }}"
- Meta row (14px ink-3): mono ink-2 date range, "Skrevet af **{{ author }}**", "Sidst opdateret " + mono timestamp, then "Kladde" / "Publiceret" pill in accent.
- Right cluster: secondary "Rediger", secondary "Eksportér ▼" (Alpine dropdown — keep current export options), primary "Publicér".

#### Tabs row
Bottom-border indicator pattern (NOT pill tabs). Tabs: Overblik, Prioriteter, Bemanding, Hændelser, Mødereferater. Active tab: ink-1 text + 2px ink-1 bottom border. Each tab can show a count badge: 11px mono in a hairline-bordered pill.

#### Overblik tab — 2fr/1fr split

*Left column*:
- **Sammendrag pull-quote card** (padding 32px). Eyebrow + 26px Instrument Serif paragraph mixing roman and italic. Then a 4-column stat grid (border-top hairline, 24px gap): each stat shows eyebrow, 28px tabular-nums value, "vs. uge 16: ±N" sub.
- **Højdepunkter card**: header "Højdepunkter — Hvad fungerede og hvad gjorde ikke". Body splits 2 columns "+ Plus" (good-ink eyebrow) / "− Minus" (bad-ink eyebrow), each a list with colored 6px bullets.

*Right column*: compact "Top prioriteter" mini-list (with checkboxes) + "Hændelser" mini-list with severity pills.

#### Prioriteter tab — single card with rows
- Section head with title "Prioriterede opgaver" + subtitle "Træk for at omarrangere · klik for at krydse af" + "Tilføj" button.
- Row grid `auto auto 1fr auto auto auto`: 14px drag handle (opacity 0, opacity 1 on row hover — wire SortableJS as today), 16px square checkbox (1.5px hairline-strong border, accent fill when checked, white check icon), title (line-through + ink-4 decoration when done, parent opacity 0.55), tag pill, 24px owner avatar, X icon-button.
- "Tilføj"-flow: insert new editable row with `--surface-2` background, `field`-styled input on `--surface-1`, Enter saves (HTMX POST), Esc cancels. Use existing HTMX endpoints — this is purely visual.
- Adding row uses a 0.18s slide-in animation (`@keyframes slideIn`).

#### Bemanding tab
Single card. Rows: 32px gradient avatar + name + role-sub, kind pill (info/accent/warn), right-aligned mono date range (200px min, "Tor 23. apr → Fre 24. apr" or "Hele uge 17"), more-icon button.

#### Hændelser tab
- **Severity summary row**: 3 cards, P1/P2/P3. Each: 44px rounded soft-tone square with stroked icon (alert/shield/clock), 26px tabular-nums count, sub label.
- **Incident cards** (collapsible): header is a clickable grid `auto 1fr auto auto`: severity pill, title + meta line ("system · timestamp · varighed value · owner"), 24px owner avatar, caret (rotates 180° when open). Open body has top hairline + `--surface-2` background, eyebrow "Sammendrag" + paragraph + two buttons "Se postmortem", "Tickets · N".
- P1 cards open by default.

#### Mødereferater tab
Card with rows. Each: mono uppercase time + dot + title (14.5px weight 600) + stacked-avatar attendees (22px circles, -6px overlap, 1.5px surface-1 border), then 13.5px ink-2 paragraph (max-width 720px, line-height 1.55).

---

## Components to extract (reusable Django partials)

Create under `templates/components/`:

- **`pill.html`** — params: `tone` (neutral/accent/good/warn/bad/info), `dot` (bool), slot for label. CSS uses `color-mix(in oklch, ...)` for neutral background.
- **`kpi_card.html`** — params: label, value, delta, delta_tone, sublabel; renders sparkline/sparkbars based on a `chart_kind` arg. Replace inner SVG with Chart.js inline mini-charts or pre-rendered SVG.
- **`section_head.html`** — title + sub + slot for actions; padding 20px 24px 16px (or 14px when `compact`).
- **`avatar.html`** — params: initials, size (24/32/44), gradient bool. Default background `color-mix(in oklch, var(--ink-3) 18%, transparent)`; gradient variant uses `linear-gradient(135deg, var(--accent), var(--accent-ink))`.
- **`segmented.html`** — pill tab control (used for "12U/26U/12M").
- **`tabs.html`** — bottom-border tab list with optional count badges. Drive selection via `?tab=overview` query string + HTMX `hx-get` on each tab.

## Interactions

| Interaction | How |
|---|---|
| Theme toggle | Existing Alpine pattern — add `dark` class on `<html>`, persist to localStorage. |
| Density toggle | Add `data-density` attr on `<html>`, persist same way. |
| Tabs in weeklog | URL `?tab=...`, HTMX `hx-get` swaps `#tab-content` partial. |
| Inline checkbox toggle | HTMX POST to `/logbook/priority-item/{id}/toggle/`, returns updated row. Optimistic CSS via `:has(input:checked)` if you want zero-latency feel. |
| Drag-reorder | Keep existing SortableJS code; restyle handle to match opacity-on-hover behavior. |
| Add priority item | HTMX `hx-get` returns the inline-edit row; on Enter, HTMX `hx-post` saves and swaps back to display row. Use `slideIn` keyframe via Tailwind's `motion-safe`. |
| Incident expand | Alpine `x-data="{ open: severity === 'P1' }"`. |
| Chart hover | Chart.js tooltip with custom HTML callback — match the `--surface-1` card with mono week label + two colored series rows. |
| Live sync indicator | Pulse on a 2s loop using the `pulseGlow` keyframe. Trigger HTMX poll to refresh. |

## Animations
Add to `input.css`:
```css
@keyframes slideIn {
  from { opacity: 0; transform: translateY(-4px); }
  to   { opacity: 1; transform: none; }
}
@keyframes pulseGlow {
  0%, 100% { box-shadow: 0 0 0 0 var(--accent-soft); }
  50%      { box-shadow: 0 0 0 6px var(--accent-soft); }
}
```

All transitions: `0.15s ease` for hover/state, `0.2s ease` for chart paths, `0.18s ease-out` for slide-in.

## Implementation Order
1. Update `tailwind.config.js` (fonts) and `static/src/input.css` (CSS variables, base body, new component classes, keyframes). Build CSS.
2. Update `templates/base.html` font links.
3. Rewrite `templates/components/nav.html` to the new shell spec.
4. Build the reusable partials listed above.
5. Rewrite `templates/dashboard/index.html` and the partials in `templates/dashboard/partials/`.
6. Rewrite `templates/logbook/weeklog_detail.html` and the partials in `templates/logbook/partials/`.
7. Replicate the prototype's Tweaks panel as a small Alpine settings menu in nav (density + accent + serif toggle), persisted to localStorage and applied as `<html>` data attrs.
8. Update PDF export styles in `static/css/pdf_styles.css` to match the editorial header (Instrument Serif H1) — important since exports are part of the product.

## Files
- `Chronicle Redesign.html` — entry HTML
- `components.jsx` — nav, pills, sparkline, sparkbars, icon set
- `dashboard.jsx` — dashboard page incl. KPI, FlowChart
- `weeklog.jsx` — weeklog page incl. tabs, overview, priorities, absences, incidents, minutes
- `app.jsx` — top-level shell + tweaks wiring
- `tweaks-panel.jsx` — tweaks framework (DO NOT port; reference only)

## Notes for the developer
- Keep all UI copy in **Danish** — labels and headings here are final.
- Keep using **server-rendered Django templates + HTMX**. Do not introduce a SPA.
- Tabular numerals (`font-variant-numeric: tabular-nums`) on every stat / timestamp / count — non-negotiable.
- Don't try to translate every Tailwind utility — the new color tokens are CSS variables, so most spacing/layout stays as Tailwind classes but colors switch to `bg-[var(--surface-1)]` / `text-[var(--ink-1)]` etc., or named utility wrappers in `@layer components`.
- Re-test PDF/email exports after the type change — WeasyPrint needs the new fonts available too.
