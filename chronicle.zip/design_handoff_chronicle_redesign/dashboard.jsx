/* global React, Icon, Pill, Sparkbars, Sparkline */
const { useState } = React;

const Dashboard = () => {
  const [hoverWeek, setHoverWeek] = useState(null);

  // Synthetic helpdesk data — last 12 weeks
  const weeks = ["W06","W07","W08","W09","W10","W11","W12","W13","W14","W15","W16","W17"];
  const openTickets = [142, 138, 145, 152, 148, 156, 161, 158, 149, 143, 138, 134];
  const newTickets =  [ 48,  52,  61,  58,  44,  62,  71,  55,  48,  52,  47,  51];
  const closedT   =  [ 51,  56,  54,  51,  48,  54,  68,  58,  57,  58,  52,  55];

  // Tasks
  const tasks = [
    { id:1, title:"Microsoft 365 license rebalancing", owner:"AS", due:"Tor", state:"in_progress", percent: 72 },
    { id:2, title:"Network upgrade — depot Odense Ø",   owner:"MJ", due:"Fre", state:"in_progress", percent: 40 },
    { id:3, title:"VPN endpoint migration to ZTNA",     owner:"LK", due:"Ons", state:"blocked",     percent: 30 },
    { id:4, title:"Q2 phishing campaign",               owner:"PK", due:"Man", state:"todo",        percent: 0 },
  ];

  const incidents = [
    { sev:"high", time:"i går · 14:32", title:"ServiceDesk Plus utilgængelig (47 min)", system:"ManageEngine", who:"AS"},
    { sev:"med",  time:"i går · 09:11", title:"Phishing-kampagne mod administration",   system:"M365 Defender", who:"PK"},
    { sev:"low",  time:"man · 16:04",   title:"Wi-Fi udfald, depot Svendborg",          system:"Cisco Meraki", who:"MJ"},
    { sev:"med",  time:"man · 08:47",   title:"Backup job timeout — fileshare-04",      system:"Veeam",         who:"LK"},
  ];

  return (
    <div style={{ padding: "32px 28px 80px", maxWidth: 1280, margin: "0 auto" }}>
      {/* === Page header ============================================== */}
      <div style={{
        display: "flex", alignItems: "flex-end", justifyContent: "space-between",
        gap: 24, marginBottom: 28, flexWrap: "wrap",
      }}>
        <div>
          <div className="label-eyebrow" style={{ marginBottom: 10 }}>
            Uge 17 · 21–27 apr 2026
          </div>
          <h1 className="display" style={{ margin: 0, fontSize: 48, lineHeight: 1.05 }}>
            Godmorgen, Mads. <span className="display italic" style={{ color: "var(--ink-3)" }}>her er ugen.</span>
          </h1>
          <div style={{ marginTop: 12, color: "var(--ink-3)", fontSize: 14.5, display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
              <span className="pill-dot" style={{ background: "var(--good)", animation: "pulseGlow 2s infinite" }} />
              Live · synkroniseret kl 09:42
            </span>
            <span style={{ color: "var(--ink-5)" }}>·</span>
            <span>4 hændelser denne uge</span>
            <span style={{ color: "var(--ink-5)" }}>·</span>
            <span>Rådighedsvagt: <strong style={{ color: "var(--ink-1)", fontWeight: 600 }}>Lasse K.</strong></span>
          </div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn btn-sm"><Icon name="download" size={14} />Eksportér</button>
          <button className="btn btn-primary btn-sm"><Icon name="plus" size={14} />Ny ugelog</button>
        </div>
      </div>

      {/* === KPI strip — 4 stats with sparklines ========================= */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gap: "var(--gutter)",
        marginBottom: "var(--gutter)",
      }}>
        <KPI label="Åbne sager" value="134" delta={-4} deltaTone="good"
             trend={openTickets} accent="var(--accent)" />
        <KPI label="Nye sager (uge)" value="51" delta={+4} deltaTone="warn"
             trend={newTickets} accent="var(--info)" />
        <KPI label="Lukkede sager" value="55" delta={+3} deltaTone="good"
             trend={closedT} accent="var(--good)" />
        <KPI label="Netto" value="−4" delta={-7} deltaTone="good"
             sublabel="bedste uge i kvartalet" accent="var(--ink-2)" sparkType="bars" trend={openTickets.map((v,i)=> closedT[i]-newTickets[i])}/>
      </div>

      {/* === Main grid: chart + side rail =============================== */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "minmax(0, 1.7fr) minmax(0, 1fr)",
        gap: "var(--gutter)",
        marginBottom: "var(--gutter)",
      }}>
        {/* === Chart card === */}
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          <div style={{
            display: "flex", justifyContent: "space-between", alignItems: "flex-start",
            padding: "20px 24px 12px",
          }}>
            <div>
              <div className="label-eyebrow">Helpdesk · 12 uger</div>
              <h2 style={{ margin: "6px 0 0", fontSize: 17, fontWeight: 600, letterSpacing: "-0.02em", color: "var(--ink-1)" }}>
                Ny vs. lukket — flow over tid
              </h2>
            </div>
            <div style={{ display: "flex", gap: 4, padding: 3, background: "var(--surface-2)", borderRadius: 8, border: "1px solid var(--hairline)" }}>
              {["12U", "26U", "12M"].map((p, i) => (
                <button key={p} style={{
                  appearance: "none", border: 0, cursor: "pointer",
                  background: i === 0 ? "var(--surface-1)" : "transparent",
                  color: i === 0 ? "var(--ink-1)" : "var(--ink-4)",
                  fontWeight: 500, fontSize: 12,
                  padding: "4px 10px", borderRadius: 6,
                  boxShadow: i === 0 ? "0 1px 2px oklch(0 0 0 / 0.06)" : "none",
                }}>{p}</button>
              ))}
            </div>
          </div>

          <FlowChart weeks={weeks} newT={newTickets} closedT={closedT} hoverWeek={hoverWeek} setHoverWeek={setHoverWeek} />

          <div style={{
            display: "flex", gap: 24, padding: "12px 24px 20px",
            borderTop: "1px solid var(--hairline)", marginTop: 4,
            fontSize: 12.5, color: "var(--ink-3)",
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
              <span style={{ width: 12, height: 3, background: "var(--info)", borderRadius: 2 }} />
              Nye sager
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
              <span style={{ width: 12, height: 3, background: "var(--good)", borderRadius: 2 }} />
              Lukkede sager
            </div>
            <div style={{ marginLeft: "auto", color: "var(--ink-4)", fontFamily: "var(--font-mono)", fontSize: 11 }}>
              Kilde: ManageEngine · synk hver 30. min
            </div>
          </div>
        </div>

        {/* === Right rail: oncall + status === */}
        <div style={{ display: "flex", flexDirection: "column", gap: "var(--gutter)" }}>
          {/* On-call */}
          <div className="card" style={{
            position: "relative", overflow: "hidden",
            background: "linear-gradient(180deg, var(--surface-1) 0%, color-mix(in oklch, var(--accent-soft) 50%, var(--surface-1)) 100%)",
          }}>
            <div className="label-eyebrow">Rådighedsvagt</div>
            <div style={{ display: "flex", alignItems: "center", gap: 14, marginTop: 12 }}>
              <div style={{
                width: 44, height: 44, borderRadius: 999,
                background: "linear-gradient(135deg, var(--accent), var(--accent-ink))",
                color: "var(--paper)",
                display: "grid", placeItems: "center",
                fontSize: 15, fontWeight: 600,
                boxShadow: "0 4px 12px var(--accent-soft)",
              }}>LK</div>
              <div>
                <div style={{ fontSize: 16, fontWeight: 600, color: "var(--ink-1)", letterSpacing: "-0.015em" }}>Lasse Kjeldsen</div>
                <div style={{ fontSize: 12.5, color: "var(--ink-3)", marginTop: 2 }}>Til mandag 08:00 · uge 17</div>
              </div>
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 16, fontSize: 12, color: "var(--ink-3)" }}>
              <button className="btn btn-sm" style={{ flex: 1, justifyContent: "center" }}>Se kalender</button>
              <button className="btn btn-sm" style={{ flex: 1, justifyContent: "center" }}>Skift</button>
            </div>
          </div>

          {/* Systemstatus */}
          <div className="card">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <div>
                <div className="label-eyebrow">Systemstatus</div>
                <div style={{ marginTop: 4, fontSize: 14.5, color: "var(--ink-1)", fontWeight: 500 }}>Alt i drift på nær én</div>
              </div>
              <Pill tone="good" dot>3 / 4 OK</Pill>
            </div>
            {[
              { label:"ManageEngine", tone:"good",  meta:"99.8% / 30d" },
              { label:"M365 / Entra",  tone:"good",  meta:"100% / 30d" },
              { label:"Veeam Backup",  tone:"warn",  meta:"degraded · job 04" },
              { label:"VPN gateway",   tone:"good",  meta:"99.9% / 30d" },
            ].map((s, i) => (
              <div key={s.label} style={{
                display: "flex", justifyContent: "space-between", alignItems: "center",
                padding: "10px 0",
                borderTop: i ? "1px solid var(--hairline)" : "none",
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
                  <span className="pill-dot" style={{
                    background: s.tone === "good" ? "var(--good)" : s.tone === "warn" ? "var(--warn)" : "var(--bad)",
                    animation: s.tone !== "good" ? "pulseGlow 2s infinite" : "none",
                  }} />
                  <span style={{ fontSize: 13.5, color: "var(--ink-1)", fontWeight: 500 }}>{s.label}</span>
                </div>
                <span style={{ fontSize: 12, fontFamily: "var(--font-mono)", color: "var(--ink-4)" }}>{s.meta}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* === Tasks + Incidents row ====================================== */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "minmax(0, 1fr) minmax(0, 1fr)",
        gap: "var(--gutter)",
      }}>
        {/* Priority tasks */}
        <div className="card" style={{ padding: 0 }}>
          <div style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            padding: "20px 24px 14px",
          }}>
            <div>
              <div className="label-eyebrow">Prioriterede opgaver</div>
              <h2 style={{ margin: "4px 0 0", fontSize: 17, fontWeight: 600, color: "var(--ink-1)", letterSpacing: "-0.02em" }}>
                I gang denne uge
              </h2>
            </div>
            <button className="btn btn-sm btn-ghost"><Icon name="plus" size={13} />Tilføj</button>
          </div>
          <div>
            {tasks.map((t, i) => (
              <div key={t.id} className="row-hoverable" style={{
                display: "grid",
                gridTemplateColumns: "auto 1fr auto auto",
                alignItems: "center", gap: 14,
                padding: "12px 24px",
                borderTop: "1px solid var(--hairline)",
                cursor: "pointer",
                transition: "background 0.12s",
              }}
              onMouseEnter={e => e.currentTarget.style.background = "var(--surface-2)"}
              onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                <div style={{
                  width: 24, height: 24, borderRadius: 999,
                  background: "color-mix(in oklch, var(--ink-3) 18%, transparent)",
                  color: "var(--ink-1)",
                  display: "grid", placeItems: "center",
                  fontSize: 10.5, fontWeight: 600,
                }}>{t.owner}</div>
                <div>
                  <div style={{ fontSize: 13.5, color: "var(--ink-1)", fontWeight: 500, letterSpacing: "-0.005em" }}>
                    {t.title}
                  </div>
                  <div style={{ marginTop: 5, display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{
                      flex: "0 0 90px", height: 4, borderRadius: 999,
                      background: "var(--surface-2)",
                      overflow: "hidden",
                    }}>
                      <div style={{
                        height: "100%", width: `${t.percent}%`,
                        background: t.state === "blocked" ? "var(--bad)" : "var(--accent)",
                        transition: "width 0.5s ease",
                      }} />
                    </div>
                    <span style={{ fontSize: 11, color: "var(--ink-4)", fontFamily: "var(--font-mono)" }}>{t.percent}%</span>
                  </div>
                </div>
                <Pill tone={t.state === "blocked" ? "bad" : t.state === "in_progress" ? "accent" : "neutral"} dot>
                  {t.state === "in_progress" ? "I gang" : t.state === "blocked" ? "Blokeret" : "Afventer"}
                </Pill>
                <div style={{ fontSize: 12, color: "var(--ink-3)", fontFamily: "var(--font-mono)", width: 36, textAlign: "right" }}>{t.due}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Incidents */}
        <div className="card" style={{ padding: 0 }}>
          <div style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            padding: "20px 24px 14px",
          }}>
            <div>
              <div className="label-eyebrow">Hændelser</div>
              <h2 style={{ margin: "4px 0 0", fontSize: 17, fontWeight: 600, color: "var(--ink-1)", letterSpacing: "-0.02em" }}>
                Sidste 7 dage
              </h2>
            </div>
            <button className="btn btn-sm btn-ghost">Se alle</button>
          </div>
          <div>
            {incidents.map((inc, i) => (
              <div key={i} style={{
                display: "grid",
                gridTemplateColumns: "auto 1fr auto",
                alignItems: "center", gap: 14,
                padding: "13px 24px",
                borderTop: "1px solid var(--hairline)",
                cursor: "pointer",
              }}>
                <div style={{
                  width: 6, alignSelf: "stretch", borderRadius: 99,
                  background: inc.sev === "high" ? "var(--bad)" : inc.sev === "med" ? "var(--warn)" : "var(--ink-4)",
                }} />
                <div>
                  <div style={{ fontSize: 13.5, color: "var(--ink-1)", fontWeight: 500 }}>
                    {inc.title}
                  </div>
                  <div style={{ marginTop: 4, display: "flex", gap: 12, fontSize: 11.5, color: "var(--ink-4)" }}>
                    <span style={{ fontFamily: "var(--font-mono)" }}>{inc.time}</span>
                    <span>{inc.system}</span>
                    <span>· {inc.who}</span>
                  </div>
                </div>
                <Pill tone={inc.sev === "high" ? "bad" : inc.sev === "med" ? "warn" : "neutral"}>
                  {inc.sev === "high" ? "P1" : inc.sev === "med" ? "P2" : "P3"}
                </Pill>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

/* ============================================================ */
const KPI = ({ label, value, delta, deltaTone, trend, accent, sublabel, sparkType }) => {
  const tone = {
    good: { fg: "var(--good-ink)", bg: "var(--good-soft)" },
    warn: { fg: "var(--warn-ink)", bg: "var(--warn-soft)" },
    bad:  { fg: "var(--bad-ink)",  bg: "var(--bad-soft)" },
  }[deltaTone] || {};
  return (
    <div className="card" style={{ display: "flex", flexDirection: "column", gap: 12, position: "relative", overflow: "hidden" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div className="label-eyebrow">{label}</div>
        <span style={{
          fontSize: 11, fontWeight: 600, letterSpacing: "-0.005em",
          padding: "2px 7px", borderRadius: 999,
          background: tone.bg, color: tone.fg,
          fontFamily: "var(--font-mono)",
          display: "inline-flex", alignItems: "center", gap: 4,
        }}>
          {delta > 0 ? "▲" : delta < 0 ? "▼" : "·"}
          {Math.abs(delta)}
        </span>
      </div>
      <div className="num" style={{
        fontSize: 38, fontWeight: 500, letterSpacing: "-0.04em",
        color: "var(--ink-1)", lineHeight: 1, fontFamily: "var(--font-ui)",
      }}>{value}</div>
      <div style={{ marginTop: -2, marginLeft: -2 }}>
        {sparkType === "bars"
          ? <Sparkbars data={trend.map(v => v + 50)} accent={accent} height={34} />
          : <Sparkline data={trend} width={180} height={34} accent={accent} />}
      </div>
      {sublabel && (
        <div style={{ fontSize: 11.5, color: "var(--ink-3)", marginTop: -4 }}>{sublabel}</div>
      )}
    </div>
  );
};

/* ============================================================ */
const FlowChart = ({ weeks, newT, closedT, hoverWeek, setHoverWeek }) => {
  const W = 720, H = 220, padL = 32, padR = 16, padT = 12, padB = 28;
  const innerW = W - padL - padR, innerH = H - padT - padB;
  const max = Math.max(...newT, ...closedT) * 1.15;
  const step = innerW / (weeks.length - 1);
  const xy = (arr) => arr.map((v, i) => [padL + i * step, padT + innerH - (v / max) * innerH]);
  const pNew = xy(newT), pCls = xy(closedT);
  const path = (pts) => pts.map((p, i) => `${i ? "L" : "M"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
  const area = (pts) => `${path(pts)} L${pts[pts.length - 1][0]},${padT + innerH} L${pts[0][0]},${padT + innerH} Z`;

  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" style={{ display: "block" }}
         onMouseLeave={() => setHoverWeek(null)}>
      {/* gridlines */}
      {[0, 0.25, 0.5, 0.75, 1].map(t => (
        <line key={t}
          x1={padL} x2={W - padR}
          y1={padT + innerH * t} y2={padT + innerH * t}
          stroke="var(--hairline)" strokeDasharray={t === 1 ? "0" : "2,4"} />
      ))}
      {/* y labels */}
      {[0, 0.5, 1].map(t => (
        <text key={t} x={padL - 8} y={padT + innerH * (1 - t) + 4}
          textAnchor="end" fontSize="10"
          fontFamily="var(--font-mono)"
          fill="var(--ink-4)">
          {Math.round(max * t)}
        </text>
      ))}
      {/* x labels */}
      {weeks.map((w, i) => (
        <text key={w} x={padL + i * step} y={H - 8}
          textAnchor="middle" fontSize="10"
          fontFamily="var(--font-mono)"
          fill={i === weeks.length - 1 ? "var(--ink-1)" : "var(--ink-4)"}>
          {w}
        </text>
      ))}
      {/* Areas */}
      <path d={area(pNew)} fill="var(--info)" opacity="0.10" />
      <path d={area(pCls)} fill="var(--good)" opacity="0.08" />
      {/* Lines */}
      <path d={path(pNew)} fill="none" stroke="var(--info)" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
      <path d={path(pCls)} fill="none" stroke="var(--good)" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
      {/* Hover hit area */}
      {weeks.map((w, i) => (
        <rect key={i}
          x={padL + i * step - step / 2} y={0}
          width={step} height={H}
          fill="transparent"
          onMouseEnter={() => setHoverWeek(i)} />
      ))}
      {/* Hover line + dots */}
      {hoverWeek != null && (
        <g>
          <line
            x1={pNew[hoverWeek][0]} x2={pNew[hoverWeek][0]}
            y1={padT} y2={padT + innerH}
            stroke="var(--ink-3)" strokeDasharray="3,3" />
          <circle cx={pNew[hoverWeek][0]} cy={pNew[hoverWeek][1]} r="4" fill="var(--info)" stroke="var(--surface-1)" strokeWidth="2" />
          <circle cx={pCls[hoverWeek][0]} cy={pCls[hoverWeek][1]} r="4" fill="var(--good)" stroke="var(--surface-1)" strokeWidth="2" />
          <g transform={`translate(${Math.min(pNew[hoverWeek][0] + 10, W - 130)}, ${padT + 6})`}>
            <rect width="120" height="50" rx="8"
              fill="var(--surface-1)" stroke="var(--hairline-strong)" />
            <text x="10" y="18" fontSize="11" fontFamily="var(--font-mono)" fill="var(--ink-3)">{weeks[hoverWeek]}</text>
            <text x="10" y="32" fontSize="11.5" fill="var(--info)">● Nye {newT[hoverWeek]}</text>
            <text x="10" y="46" fontSize="11.5" fill="var(--good)">● Lukket {closedT[hoverWeek]}</text>
          </g>
        </g>
      )}
      {/* Last point dots */}
      <circle cx={pNew[pNew.length-1][0]} cy={pNew[pNew.length-1][1]} r="4" fill="var(--info)" />
      <circle cx={pCls[pCls.length-1][0]} cy={pCls[pCls.length-1][1]} r="4" fill="var(--good)" />
    </svg>
  );
};

Object.assign(window, { Dashboard });
